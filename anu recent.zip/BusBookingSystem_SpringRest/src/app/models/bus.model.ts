export class Bus {
    $key:string
    coach_type:string;
    fare:number;
    location:string;
    name:string;
    seat:number;
    time:string;

}