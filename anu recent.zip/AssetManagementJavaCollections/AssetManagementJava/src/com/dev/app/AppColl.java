package com.dev.app;


import java.util.Scanner;

import com.dev.beans.Asset;
import com.dev.beans.AssetAllocation;
import com.dev.beans.Employee;
import com.dev.beans.UserMaster;
import com.dev.exceptions.ValidationException;
import com.dev.services.Services;
import com.dev.services.ServicesImpl;
import com.dev.validations.Validate;

public class AppColl {

	public static void main(String[] args) {
		ValidationException validationexception=new ValidationException();
		Integer count=1;
		Services s=new ServicesImpl();
		Scanner sc=new Scanner(System.in);
		Validate valid=new Validate();
	jump2 :while(true)
		{
			System.out.println("***************Asset Management System***************");
			System.out.println("enter the number of your choice ");
			System.out.println("1. Admin");
			System.out.println("2. manager");
			System.out.println("3. exit program");
			Integer num=sc.nextInt();
			if(num==2)
			{
				System.out.println("enter the user id");
				Integer userid=sc.nextInt();
				System.out.println("enter user password");
				String password=sc.next();

				UserMaster um=s.loginService(userid, password);
				if(um.getUsertype().equalsIgnoreCase("manager")) {
					System.out.println("Manager is Logged in successfully");


				jump1:	while(true)
				{	
					System.out.println("To perform an operation");
					System.out.println("enter your choice");
					System.out.println("1.Add employee");
					System.out.println("2.Raise Allocation ");
					System.out.println("3.View Status");
					System.out.println("4. Exit");
					Integer choice1=sc.nextInt();
					switch(choice1)
					{
					case 1:Employee e=new Employee();
					System.out.println("enter employee id");
					String empid=sc.next();
					Boolean b=valid.idValidation(empid);
					jump:while(!b)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							empid=sc.next();
							if(valid.idValidation(empid))
							{
								break jump;
							}
						}
					}
					e.setEmpno(Integer.parseInt(empid));
					System.out.println("enter the employee name");

					String name=sc.next();
					Boolean b1=valid.idValidation(name);
					jumpvalidate:while(b1)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter the name in string format");
							name=sc.next();
							if(!valid.idValidation(name))
							{
								break jumpvalidate;
							}
						}
					}
					e.setEname(name);
					System.out.println("enter deptid of the employee");
					String deptid=sc.next();

					Boolean b2=valid.idValidation(deptid);
					jump:while(!b2)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							deptid=sc.next();
							if(valid.idValidation(deptid))
							{
								break jump;
							}
						}
					}
					e.setDeptid(Integer.parseInt(deptid));
					System.out.println("enter hiredate of the employee");
					String hiredate=sc.next();
					Boolean b3=valid.dateValidation(hiredate);
					jump:while(!b3)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter in YYYY/MM/DD format");
							hiredate=sc.next();
							if(!valid.idValidation(hiredate))
							{
								break jump;
							}
						}
					}
					e.setHiredate(hiredate);
					System.out.println("enter job of employee");
					String job=sc.next();
					Boolean b4=valid.idValidation(job);
					jumpvalidate:while(b4)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter in string format");
							job=sc.next();
							if(!valid.idValidation(job))
							{
								break jumpvalidate;
							}
						}
					}
					e.setJob(job);
					System.out.println("enter mgr number");
					String mgr=sc.next();

					Boolean b5=valid.idValidation(mgr);
					jump:while(!b5)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							mgr=sc.next();
							if(valid.idValidation(mgr))
							{
								break jump;
							}
						}
					}
					e.setMgrno(Integer.parseInt(mgr));
					System.out.println("Added Employee is:"+s.addEmployeeService(e));
					break;
					case 2:AssetAllocation aa=new AssetAllocation();
					aa.setAllocationid(count);
					System.out.println("Enter Asset id ");
					String assetid=sc.next();

					Boolean b6=valid.idValidation(assetid);
					jump:while(!b6)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							assetid=sc.next();
							if(valid.idValidation(assetid))
							{
								break jump;
							}
						}
					}
					aa.setAssetid(Integer.parseInt(assetid));

					System.out.println("Enter employee number");
					String empno=sc.next();

					Boolean b7=valid.idValidation(empno);
					jump:while(!b7)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							empno=sc.next();
							if(valid.idValidation(empno))
							{
								break jump;
							}
						}
					}
					aa.setEmpno(Integer.parseInt(empno));
					System.out.println("Enter allocation date");
					String date=sc.next();
					Boolean b8=valid.dateValidation(date);
					jump:while(!b8)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter in YYYY/MM/DD format");
							date=sc.next();
							if(!valid.idValidation(date))
							{
								break jump;
							}
						}
					}
					aa.setAllocationdate(date);
					System.out.println("Enter release date ");
					String reldate=sc.next();
					Boolean b9=valid.dateValidation(reldate);
					jump:while(!b9)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter in YYYY/MM/DD format");
							reldate=sc.next();
							if(!valid.idValidation(reldate))
							{
								break jump;
							}
						}
					}
					aa.setReleasedate(reldate);
					System.out.println("Enter quantity");
					String quantity=sc.next();

					Boolean b10=valid.idValidation(quantity);
					jump:while(!b10)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							System.out.println("enter again");
							quantity=sc.next();
							if(valid.idValidation(quantity))
							{
								break jump;
							}
						}
					}
					aa.setQuantity(Integer.parseInt(quantity));
					System.out.println("Raised allocation request :"+s.raiseAllocationService(aa));
					System.out.println("Randomly generated allocation id :"+aa.getAllocationid());
					count++;
					break;
					case 3:System.out.println("enter the allocation id");
					String allocationid=sc.next();

					Boolean b11=valid.idValidation(allocationid);
					jump:while(!b11)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							System.out.println("enter again");
							allocationid=sc.next();
							if(valid.idValidation(allocationid))
							{
								break jump;
							}
						}
					}
					System.out.println(s.viewStatusService(Integer.parseInt(allocationid)));
					break;
					case 4: System.out.println("manager logged out successfully"); 
					break jump1;
					default:System.out.println("enter valid number");
					break;

					}

				}
				}else {
					System.out.println("Enter the correct admin id and password");
				}
			}
				

			else if(num==1)
			{
				System.out.println("enter the user id");
				Integer userid=sc.nextInt();
				System.out.println("enter password");
				String password=sc.next();

				UserMaster um=s.loginService(userid, password);
				if(um.getUsertype().equalsIgnoreCase("admin")) {

					System.out.println("admin");
				jump:	while(true)
				{
					System.out.println("enter your choice");
					System.out.println("1.add asset");
					System.out.println("2.Remove asset");
					System.out.println("3. update asset");
					System.out.println("4. view all asset");
					System.out.println("5. view all allocation request");
					System.out.println("6. set allocation status");
					System.out.println("7. exit");
					Integer choice=sc.nextInt();
					switch(choice)
					{
					case 1:Asset a=new Asset();
					System.out.println("enter asset id");
					String assid=sc.next();

					Boolean b=valid.idValidation(assid);
					jumpadmin:while(!b)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							System.out.println("enter again");
							assid=sc.next();
							if(valid.idValidation(assid))
							{
								break jumpadmin;
							}
						}
					}
					a.setAssetid(Integer.parseInt(assid));
					System.out.println(" enter asset name ");	
					String assname=sc.next();
					Boolean b1=valid.idValidation(assname);
					jumpadmin:while(b1)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter in string format");
							System.out.println("enter again");
							assname=sc.next();
							if(!valid.idValidation(assname))
							{
								break jumpadmin;
							}
						}
					}

					a.setAssetname(assname);
					System.out.println("enter asset des");
					a.setAssetdes(sc.next());
					System.out.println("enter asset quantity");
					String assetquantity=sc.next();

					Boolean b2=valid.idValidation(assetquantity);
					jumpadmin:while(!b2)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							System.out.println("enter again");
							assetquantity=sc.next();
							if(valid.idValidation(assetquantity))
							{
								break jumpadmin;
							}
						}
					}
					a.setQuantity(Integer.parseInt(assetquantity));
					System.out.println(" enter asset status ");
					String status=sc.next();
					Boolean b3=valid.idValidation(status);
					jumpadmin:while(b3)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter in string format");
							System.out.println("enter again");
							status=sc.next();
							if(!valid.idValidation(status))
							{
								break jumpadmin;
							}
						}
					}
					a.setStatus(status);

					System.out.println("Added asset :"+s.addAssetService(a));
					break;
					case 2:System.out.println("enter the asset id you want to remove");
					Asset a1=new Asset();
					String assid1=sc.next();

					Boolean b4=valid.idValidation(assid1);
					jumpadmin:while(!b4)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							System.out.println("enter again");
							assid1=sc.next();
							if(valid.idValidation(assid1))
							{
								break jumpadmin;
							}
						}
					}
					a1=s.removeAssetService(Integer.parseInt(assid1));
					System.out.println("removed asset is :"+a1);
					break;
					case 3: System.out.println("enter the asset id you want to update");
					String assid2=sc.next();

					Boolean b5=valid.idValidation(assid2);
					jumpadmin:while(!b5)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							System.out.println("enter again");
							assid2=sc.next();
							if(valid.idValidation(assid2))
							{
								break jumpadmin;
							}
						}
					}

					System.out.println("updated asset information :"+s.updateAssetService(Integer.parseInt(assid2)));
					break;
					case 4:System.out.println("assets are");
					s.getAllAssetService();
					break;
					case 5:s.getAllAssetAllocationService();
					break;
					case 6:System.out.println("enter allocation id to set status");

					String allocationid=sc.next();

					Boolean b6=valid.idValidation(allocationid);
					jumpadmin:while(!b6)
					{
						try {
							throw validationexception;
						}
						catch(ValidationException e1)
						{
							System.out.println("please enter number");
							System.out.println("enter again");
							allocationid=sc.next();
							if(valid.idValidation(allocationid))
							{
								break jumpadmin;
							}
						}
					}
					Integer allocation_id=Integer.parseInt(allocationid);

					if(s.setStatusService(allocation_id))
					{
						System.out.println("status changed");
					}
					else
					{
						System.out.println("status not changed");
					}
					break;
					//case 7:
					case 7:System.out.println("admin logged out successfully");
					break jump;
					default:System.out.println("enter valid number");
					break;
					}
				}
				}else {
					System.out.println("Enter correct manager id and password");
				}
			}
			else if(num==3)
			{
				System.out.println("Thank you...visit again");
				sc.close();
				break jump2;
			}

		}
		}
	}



