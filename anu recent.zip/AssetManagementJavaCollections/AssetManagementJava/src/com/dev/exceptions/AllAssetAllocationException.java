package com.dev.exceptions;

public class AllAssetAllocationException extends RuntimeException {
	public String getMessage()
	{
		return "all asset allocation exception";

	}
}
