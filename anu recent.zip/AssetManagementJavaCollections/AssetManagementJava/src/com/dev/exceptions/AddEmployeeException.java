package com.dev.exceptions;

public class AddEmployeeException extends RuntimeException {
	public String getMessage()
	{
		return "add employee exception";

	}
}
