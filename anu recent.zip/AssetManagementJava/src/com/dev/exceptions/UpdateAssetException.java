package com.dev.exceptions;

public class UpdateAssetException extends RuntimeException {
public String getMessage()
{
	return "Update asset exception";
	
}
}
