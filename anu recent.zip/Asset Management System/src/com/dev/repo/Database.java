package com.dev.repo;

import java.util.HashMap;

import com.dev.beans.Admin;
import com.dev.beans.Asset;
import com.dev.beans.AssetAllocation;
import com.dev.beans.Department;
import com.dev.beans.Employee;
import com.dev.beans.Manager;
import java.util.Date;

public class Database 
{
	public static HashMap<Integer, Manager> manager = new HashMap<>();
	public static HashMap<Integer,Asset> asset = new HashMap<>();
	public static HashMap<Integer,Admin> admin = new HashMap<>();
	public static HashMap<Integer, Employee> emp = new HashMap<>();
	public static HashMap<Integer, Department> dept = new HashMap<>();
	public static HashMap<Integer, AssetAllocation> allocate = new HashMap<>();
	
	public Database()
	{
		Manager manager1 = new Manager();
		manager1.setUserId(101);
		manager1.setUserName("Steve");
		manager1.setUserType("Manager");
		manager1.setUserPassword("Captain");
		manager.put(manager1.getUserId(), manager1);
		
		Manager manager2 = new Manager();
		manager2.setUserId(102);
		manager2.setUserName("Peter");
		manager2.setUserType(" Senior Manager");
		manager2.setUserPassword("Parker");
		manager.put(manager2.getUserId(), manager2);
		
		Manager manager3 = new Manager();
		manager3.setUserId(103);
		manager3.setUserName("Ben");
		manager3.setUserType("Manager");
		manager3.setUserPassword("Tenyson");
		manager.put(manager3.getUserId(), manager3);
		
		Asset asset1 = new Asset();
		asset1.setAssetId(10);
		asset1.setAssetName("Dell 650 Desktop");
		asset1.setAssetDes("Desktop Computer");
		asset1.setQuantity(4);
		asset1.setStatus("good");
		asset.put(asset1.getAssetId(), asset1);
		
		Asset asset2 = new Asset();
		asset2.setAssetId(20);
		asset2.setAssetName("Lenovo 330 Desktop");
		asset2.setAssetDes("Desktop Computer");
		asset2.setQuantity(3);
		asset2.setStatus("good");
		asset.put(asset2.getAssetId(), asset2);
		
		Asset asset3 = new Asset();
		asset3.setAssetId(30);
		asset3.setAssetName("Hp laser printer");
		asset3.setAssetDes("Printer");
		asset3.setQuantity(2);
		asset3.setStatus("ok");
		asset.put(asset3.getAssetId(), asset3);
		
		Asset asset4 = new Asset();
		asset4.setAssetId(50);
		asset4.setAssetName("Panasonic Fx");
		asset4.setAssetDes("Faxer");
		asset4.setQuantity(3);
		asset4.setStatus("new");
		asset.put(asset4.getAssetId(), asset4);
		
		Department dept1 = new Department();
		dept1.setDeptId(111);
		dept1.setDeptName("Sales");
		dept.put(dept1.getDeptId(), dept1);
		
		Department dept2 = new Department();
		dept2.setDeptId(222);
		dept2.setDeptName("Operation");
		dept.put(dept2.getDeptId(), dept2);
		
		Department dept3 = new Department();
		dept3.setDeptId(333);
		dept3.setDeptName("Accounting");
		dept.put(dept3.getDeptId(), dept3);
		
		AssetAllocation allocate1 = new AssetAllocation();
		allocate1.setAllocationId(100);
		allocate1.setAssetId(10);
		allocate1.setAllocationDate("2019-07-08");
		allocate1.setReleaseDate("2018-12-06");
		allocate.put(allocate1.getAllocationId(), allocate1);
		
		AssetAllocation allocate2 = new AssetAllocation();
		allocate2.setAllocationId(200);
		allocate2.setAssetId(20);
		allocate2.setAllocationDate("2019-24-08");
		allocate2.setReleaseDate("2017-09-01");
		allocate.put(allocate2.getAllocationId(), allocate2);
		
		AssetAllocation allocate3 = new AssetAllocation();
		allocate3.setAllocationId(300);
		allocate3.setAssetId(30);
		allocate3.setAllocationDate("2018-04-05");
		allocate3.setReleaseDate("2017-05-10");
		allocate.put(allocate3.getAllocationId(), allocate3);
		
		Employee emp1 = new Employee();
		emp1.setEmpno(1);
		emp1.setEmpName("Akanksha");
		emp1.setJob("Analyst");
		emp1.setMgr(3);
		emp1.setHireDate("2017/4/19");
		emp1.setDeptId(222);
		emp.put(emp1.getEmpno(), emp1);
		
		Employee emp2 = new Employee();
		emp2.setEmpno(2);
		emp2.setEmpName("Siddharth");
		emp2.setJob("Salesman");
		emp2.setMgr(1);
		emp2.setHireDate("2019-04-08");
		emp2.setDeptId(333);
		emp.put(emp2.getEmpno(), emp2);
		
		Employee emp3 = new Employee();
		emp3.setEmpno(3);
		emp3.setEmpName("Manoj");
		emp3.setJob("President");
		emp3.setMgr(0);
		emp3.setHireDate("2018-01-08");
		emp3.setDeptId(333);
		emp.put(emp3.getEmpno(), emp3);
		
		Employee emp4 = new Employee();
		emp4.setEmpno(4);
		emp4.setEmpName("Manju");
		emp4.setJob("Analyst");
		emp4.setMgr(3);
		emp4.setHireDate("2018/7/17");
		emp4.setDeptId(222);
		emp.put(emp4.getEmpno(), emp4);
		
		Employee emp5 = new Employee();
		emp5.setEmpno(5);
		emp5.setEmpName("Neeraj");
		emp5.setJob("Salesman");
		emp5.setMgr(4);
		emp5.setHireDate("2017/3/20");
		emp5.setDeptId(111);
		emp.put(emp5.getEmpno(), emp5);
		
		Employee emp6 = new Employee();
		emp6.setEmpno(6);
		emp6.setEmpName("Anju");
		emp6.setJob("Clerk");
		emp6.setMgr(4);
		emp6.setHireDate("2015/1/29");
		emp6.setDeptId(333);
		emp.put(emp6.getEmpno(), emp6);
			
		
	}

}
