package com.dev.beans;

public class Asset 
{
	private Integer AssetId;
	private String AssetName;
	private String AssetDes;
	private Integer Quantity;
	private String Status;
	public Integer getAssetId() {
		return AssetId;
	}
	public void setAssetId(Integer assetId) {
		AssetId = assetId;
	}
	public String getAssetName() {
		return AssetName;
	}
	public void setAssetName(String assetName) {
		AssetName = assetName;
	}
	public String getAssetDes() {
		return AssetDes;
	}
	public void setAssetDes(String assetDes) {
		AssetDes = assetDes;
	}
	public Integer getQuantity() {
		return Quantity;
	}
	public void setQuantity(Integer quantity) {
		Quantity = quantity;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	@Override
	public String toString() {
		return "Asset [AssetId=" + AssetId + ", AssetName=" + AssetName + ", AssetDes=" + AssetDes + ", Quantity="
				+ Quantity + ", Status=" + Status + "]";
	}
	
	

}
