package com.dev.beans;

public class Employee 
{
	private Integer Empno;
	private String EmpName;
	private String Job;
	private Integer Mgr;
	private String HireDate;
	private Integer DeptId;
	public Integer getEmpno() {
		return Empno;
	}
	public void setEmpno(Integer empno) {
		Empno = empno;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public String getJob() {
		return Job;
	}
	public void setJob(String job) {
		Job = job;
	}
	public Integer getMgr() {
		return Mgr;
	}
	public void setMgr(Integer mgr) {
		Mgr = mgr;
	}
	public String getHireDate() {
		return HireDate;
	}
	public void setHireDate(String hireDate) {
		HireDate = hireDate;
	}
	public Integer getDeptId() {
		return DeptId;
	}
	public void setDeptId(Integer deptId) {
		DeptId = deptId;
	}
	@Override
	public String toString() {
		return "Employee [Empno=" + Empno + ", EmpName=" + EmpName + ", Job=" + Job + ", Mgr=" + Mgr + ", HireDate="
				+ HireDate + ", DeptId=" + DeptId + "]";
	}
	

}
