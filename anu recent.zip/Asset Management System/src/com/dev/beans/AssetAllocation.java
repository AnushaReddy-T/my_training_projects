package com.dev.beans;

import java.util.Date;

public class AssetAllocation 
{
	private Integer AllocationId;
	private Integer AssetId;
	private String AllocationDate;
	private String ReleaseDate;
	public Integer getAllocationId() {
		return AllocationId;
	}
	public void setAllocationId(Integer allocationId) {
		AllocationId = allocationId;
	}
	public Integer getAssetId() {
		return AssetId;
	}
	public void setAssetId(Integer assetId) {
		AssetId = assetId;
	}
	public String getAllocationDate() {
		return AllocationDate;
	}
	public void setAllocationDate(String allocationDate) {
		AllocationDate = allocationDate;
	}
	public String getReleaseDate() {
		return ReleaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		ReleaseDate = releaseDate;
	}
	@Override
	public String toString() {
		return "AssetAllocation [AllocationId=" + AllocationId + ", AssetId=" + AssetId + ", AllocationDate="
				+ AllocationDate + ", ReleaseDate=" + ReleaseDate + "]";
	}
	
	
	
	 
	
	

}
