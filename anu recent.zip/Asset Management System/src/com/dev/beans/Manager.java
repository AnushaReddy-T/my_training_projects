package com.dev.beans;

public class Manager 
{
	
	private Integer UserId;
	private String UserName;
	private String UserType;
	private String UserPassword;
	public Integer getUserId() {
		return UserId;
	}
	public void setUserId(Integer userId) {
		UserId = userId;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserType() {
		return UserType;
	}
	public void setUserType(String userType) {
		UserType = userType;
	}
	public String getUserPassword() {
		return UserPassword;
	}
	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}
	@Override
	public String toString() {
		return "Manager [UserId=" + UserId + ", UserName=" + UserName + ", UserType=" + UserType + ", UserPassword="
				+ UserPassword + "]";
	}
	
	
	

}
