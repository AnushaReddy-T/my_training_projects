package com.dev.beans;

public class Admin 
{
	private Integer AdminId;
	private String Password;
	public Integer getAdminId() {
		return AdminId;
	}
	public void setAdminId(Integer adminId) {
		AdminId = adminId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	@Override
	public String toString() {
		return "Admin [AdminId=" + AdminId + ", Password=" + Password + "]";
	}
	
	
	

}
