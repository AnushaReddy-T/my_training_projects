package com.dev.service;

import com.dev.beans.Admin;
import com.dev.beans.Asset;

public interface AdminService 
{
    public Boolean createAssetService(Asset asset);
	
	public Boolean updateAssetService(Integer AssetId, String AssetName, String AssetDes, String Status);
	
	public Asset searchAssetService(Integer AssetId);
	
	public Boolean deleteAssetService(Integer AssetId);
	
	public Boolean adminLoginService(Integer AdminId, String Password);
	
	public Admin searchAdminService(Integer AdminId);

	

}
