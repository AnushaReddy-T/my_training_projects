package com.dev.service;

public interface ManagerService {

}
