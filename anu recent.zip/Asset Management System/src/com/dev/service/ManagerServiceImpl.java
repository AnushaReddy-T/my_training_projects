package com.dev.service;

public class ManagerServiceImpl {

}
