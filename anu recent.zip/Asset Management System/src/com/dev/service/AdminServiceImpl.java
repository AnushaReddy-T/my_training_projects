package com.dev.service;

import com.dev.beans.Admin;
import com.dev.beans.Asset;
import com.dev.dao.AdminDAO;
import com.dev.dao.AdminDAOImpl;

public class AdminServiceImpl implements AdminService 
{
	AdminDAO admin = new AdminDAOImpl();

	@Override
	public Boolean createAssetService(Asset asset) {
		
		return admin.createAsset(asset);
	}

	@Override
	public Boolean updateAssetService(Integer AssetId, String AssetName, String AssetDes, String Status) {
		
		return admin.updateAsset(AssetId, AssetName, AssetDes, Status);
	}

	@Override
	public Asset searchAssetService(Integer AssetId) {
		
		return admin.searchAsset(AssetId);
	}

	@Override
	public Boolean deleteAssetService(Integer AssetId) {
		
		return admin.deleteAsset(AssetId);
	}

	@Override
	public Boolean adminLoginService(Integer AdminId, String Password) {
		
		return admin.adminLogin(AdminId, Password);
	}

	@Override
	public Admin searchAdminService(Integer AdminId) {
		
		return admin.searchAdmin(AdminId);
	}
	
	

}
