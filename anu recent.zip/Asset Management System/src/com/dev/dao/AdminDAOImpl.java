package com.dev.dao;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.dev.beans.Admin;
import com.dev.beans.Asset;
import com.dev.repo.Database;

public class AdminDAOImpl implements AdminDAO 
{
	Database repo = new Database();
	HashMap<Integer, Asset> assetdb = Database.asset;
	HashMap<Integer, Admin> admindb = Database.admin;
	Admin admin = new Admin();
	
	@SuppressWarnings("unused")
	@Override
	public Boolean createAsset(Asset asset) {
		 assetdb.put(asset.getAssetId(), asset);
		 if(asset !=null)
		 {
			 return true;
		 }
		 else
		 {
			 return false;
		 }
	}
	@Override
	public Boolean updateAsset(Integer AssetId, String AssetName, String AssetDes, String Status) {
		 
		Asset asset = searchAsset(AssetId);
		if(asset !=null)
		{
			asset.setAssetId(AssetId);
			asset.setAssetName(AssetName);
			asset.setAssetDes(AssetDes);
			asset.setStatus(Status);
			assetdb.put(asset.getAssetId(), asset);
			return true;
		}
		return false;
	}
	@Override
	public Asset searchAsset(Integer AssetId) {
		
		 Asset asset = null;
		 Iterator<Entry<Integer, Asset>> it = assetdb.entrySet().iterator();
		 while(it.hasNext())
		 {
			 Map.Entry<Integer, Asset> pair = it.next();
			 if(pair.getKey().equals(AssetId))
			 {
				 return (Asset) pair.getValue();
			 }
		 }
		 return asset;
	}
	@Override
	public Boolean deleteAsset(Integer AssetId) {
		
		Asset asset = searchAsset(AssetId);
		if(asset !=null )
		{
			assetdb.remove(AssetId);
			return true;
		}
		return false;
	}
	@Override
	public Boolean adminLogin(Integer AdminId, String Password) {
		
		if(admindb.containsKey(AdminId))
		{
			Admin admin = admindb.get(AdminId);
			if(admin.getPassword().equals(Password))
			{
				return true;
			}
		}
		return false;
	}
	@Override
	public Admin searchAdmin(Integer AdminId) {
		
		Admin admin = null;
		Iterator<Entry<Integer, Admin>> it = admindb.entrySet().iterator();
		while(it.hasNext())
		{
			Map.Entry<Integer, Admin> pair = it.next();
			if(pair.getKey().equals(AdminId))
			{
				return pair.getValue();
			}
		}
		return admin;
	}
}
