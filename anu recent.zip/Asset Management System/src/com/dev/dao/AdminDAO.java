package com.dev.dao;

import com.dev.beans.Admin;
import com.dev.beans.Asset;

public interface AdminDAO 
{
	public Boolean createAsset(Asset asset);
	
	public Boolean updateAsset(Integer AssetId, String AssetName, String AssetDes, String Status);
	
	public Asset searchAsset(Integer AssetId);
	
	public Boolean deleteAsset(Integer AssetId);
	
	public Boolean adminLogin(Integer AdminId, String Password);
	
	public Admin searchAdmin(Integer AdminId); 

}
