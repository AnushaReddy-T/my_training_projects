package com.dev.dao;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

import com.dev.beans.Asset;
import com.dev.beans.Department;
import com.dev.beans.Employee;
import com.dev.beans.Manager;
import com.dev.repo.Database;
import com.dev.beans.AssetAllocation;


public class ManagerDAOImpl implements ManagerDAO 
{
	Database repo = new Database();
	HashMap<Integer, Asset> assetdb = Database.asset;
	HashMap<Integer, Manager> managerdb = Database.manager;
	HashMap<Integer, Department> departmentdb = Database.dept;
	HashMap<Integer, Employee> employeedb = Database.emp;
	HashMap<Integer, AssetAllocation> assetallocationdb = Database.allocate;
	
	Scanner sc = new Scanner(System.in);
	Manager manager = new Manager();
	Employee emp = new Employee();
	Asset asset = new Asset();

	@SuppressWarnings("unused")
	@Override
	public Boolean createManager(Manager manager) {
		managerdb.put(manager.getUserId(), manager);
		if(manager != null)
			return true;
		else
			return false;
	}

	@Override
	public Boolean updateManager(Integer UserId, String Password, String UserName) {
		Manager manager = searchManager(UserId);
		if(manager !=null)
		{
			manager.setUserId(UserId);
			manager.setUserName(UserName);
			manager.setUserPassword(Password);	
		}
			return false;
		
				
	}

	@Override
	public Boolean deleteManager(Integer UserId) {
		Manager manager = searchManager(UserId);
		if(manager!=null)
		{
			managerdb.remove(UserId);
			return true;
		}
		return false;
	}

	@Override
	public Boolean loginManager(Integer UserId, String Password) {
		Manager manager = searchManager(UserId);
		if(manager !=null)
		{
			if(manager.getUserPassword().equals(Password)){
				return true;
			}
		}
		return false;
	}

	@Override
	public Manager searchManager(Integer UserId) {
		return null;
		
	}

	@Override
	public Manager searchManager(String UserName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean bookAsset(Employee emp) {
		Integer Empno = emp.getEmpno();
		String EmpName = emp.getEmpName();
		String HireDate = emp.getHireDate();
		Integer DeptId = emp.getDeptId();
		Random randomNumGenerator = new Random();
		Integer AllocationId = randomNumGenerator.nextInt(10);
		try{
			Asset asset = assetdb.get(DeptId);
			System.out.println(asset);
			
		}
	}

	@Override
	public Boolean cancelAsset(Integer AssetId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Asset getAsset(Integer AssetId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Asset getAllAsset() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Asset searchAsset(Integer AssetId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer AssetAllocation(Integer AssetId, Integer AllocationDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.dev.beans.AssetAllocation searchAssetAllocation(Integer AssetId) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
