package com.dev.dao;
import com.dev.beans.AssetAllocation;
import com.dev.beans.Employee;
import com.dev.beans.Asset;
import com.dev.beans.Manager;

public interface ManagerDAO 
{
	public Boolean createManager(Manager manager); // For create user operation

	public Boolean updateManager(Integer UserId, String Password, String UserName);

	public Boolean deleteManager(Integer UserId); // For delete operation of user

	public Boolean loginManager(Integer UserId, String Password); // For login of user
	
    public Manager searchManager(Integer UserId); // For searching of user using user id
	
	public Manager searchManager(String UserName); //For searching user by username
	
	public Boolean bookAsset(Employee emp); // For booking tickets

	public Boolean cancelAsset(Integer AssetId); // For canceling ticket

	public Asset getAsset(Integer AssetId); // For getting ticket
	
	public Asset getAllAsset();
	
	public Asset searchAsset(Integer AssetId);
	
	public Integer AssetAllocation(Integer AssetId, Integer AllocationDate);
	
	public AssetAllocation searchAssetAllocation(Integer AssetId);
	
	
	

}
